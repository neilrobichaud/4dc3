Neil Robichaud 001425566
FIND Q3 in timediagram.png